# نشر البوت على Fly.io

## 1. تثبيت flyctl

```bash
curl -L https://fly.io/install.sh | sh
flyctl auth login
```

---

## 2. إنشاء التطبيق (مرة واحدة فقط)

```bash
cd tgbot
flyctl launch --no-deploy
```

- اقبل الاسم أو غيّره
- اختر region: **fra** (Frankfurt)
- لا تضيف Postgres أو Redis

---

## 3. رفع المتغيرات السرية

```bash
flyctl secrets set \
  BOT_TOKEN="your_bot_token_here" \
  WEBHOOK_URL="https://YOUR-APP-NAME.fly.dev"
```

> `WEBHOOK_URL` هو الدومين الذي يعطيك إياه fly.io بعد `flyctl launch`  
> صيغته: `https://tg-downloader-bot.fly.dev`

---

## 4. النشر

```bash
flyctl deploy
```

---

## 5. التحقق من التشغيل

```bash
flyctl logs          # سجلات حية
flyctl status        # حالة الـ machine
```

---

## ملاحظات

| الموضوع | التفاصيل |
|---------|----------|
| حد حجم الملف | 50 MB (حد تيليجرام للبوتات) |
| ffmpeg | مثبت داخل Docker — ضروري لدمج الفيديو والصوت |
| yt-dlp | يُحدَّث تلقائياً عند كل `flyctl deploy` |
| `auto_stop_machines = false` | يمنع النوم — مهم للـ webhook |

---

## تحديث yt-dlp يدوياً (إذا توقف موقع معين)

```bash
flyctl ssh console
pip install -U yt-dlp
exit
```

أو أضف في Dockerfile:
```dockerfile
RUN pip install --no-cache-dir -r requirements.txt && pip install -U yt-dlp
```
ثم `flyctl deploy` من جديد.
