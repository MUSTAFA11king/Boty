"""
Telegram Downloader Bot
Supports: TikTok, Instagram, Facebook, YouTube, X (Twitter), Reddit
Mode: Webhook via python-telegram-bot + yt-dlp
"""

import os
import re
import logging
import asyncio
import tempfile
import subprocess
from pathlib import Path

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    ContextTypes,
    filters,
)
from telegram.constants import ParseMode, ChatAction

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

# ── Config ────────────────────────────────────────────────────────────────────
BOT_TOKEN = os.environ["BOT_TOKEN"]
WEBHOOK_URL = os.environ["WEBHOOK_URL"]          # e.g. https://your-app.fly.dev
PORT = int(os.environ.get("PORT", 8080))
MAX_FILE_MB = int(os.environ.get("MAX_FILE_MB", 50))  # Telegram bot limit = 50 MB

# ── URL detection ─────────────────────────────────────────────────────────────
PLATFORM_PATTERNS = {
    "TikTok":    r"(tiktok\.com|vm\.tiktok\.com)",
    "Instagram": r"instagram\.com\/(p|reel|tv|stories)\/",
    "Facebook":  r"(facebook\.com|fb\.watch|fb\.com)",
    "YouTube":   r"(youtube\.com\/watch|youtu\.be|youtube\.com\/shorts)",
    "X":         r"(twitter\.com|x\.com)\/\w+\/status\/",
    "Reddit":    r"(reddit\.com|redd\.it)\/",
}

URL_REGEX = re.compile(r"https?://[^\s]+")


def detect_platform(url: str) -> str:
    for platform, pattern in PLATFORM_PATTERNS.items():
        if re.search(pattern, url, re.IGNORECASE):
            return platform
    return "Unknown"


def extract_url(text: str) -> str | None:
    match = URL_REGEX.search(text)
    return match.group(0) if match else None


# ── yt-dlp download ───────────────────────────────────────────────────────────
async def download_media(url: str, quality: str = "best") -> tuple[Path | None, str]:
    """
    Returns (file_path, error_message).
    quality: 'best' | 'audio'
    """
    with tempfile.TemporaryDirectory() as tmpdir:
        out_template = os.path.join(tmpdir, "%(title).50s.%(ext)s")

        if quality == "audio":
            cmd = [
                "yt-dlp",
                "--no-playlist",
                "--extract-audio",
                "--audio-format", "mp3",
                "--audio-quality", "0",
                "-o", out_template,
                url,
            ]
        else:
            cmd = [
                "yt-dlp",
                "--no-playlist",
                "--merge-output-format", "mp4",
                "-f", "bestvideo[ext=mp4][filesize<45M]+bestaudio[ext=m4a]/best[ext=mp4][filesize<45M]/best[filesize<45M]",
                "-o", out_template,
                "--max-filesize", f"{MAX_FILE_MB}M",
                url,
            ]

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            _, stderr = await asyncio.wait_for(proc.communicate(), timeout=120)

            if proc.returncode != 0:
                err = stderr.decode(errors="replace").strip().splitlines()
                last = next((l for l in reversed(err) if l.strip()), "unknown error")
                return None, last

            files = list(Path(tmpdir).iterdir())
            if not files:
                return None, "no output file produced"

            # move to a persistent temp location before tmpdir is deleted
            target = files[0]
            dest = Path(tempfile.gettempdir()) / target.name
            target.rename(dest)
            return dest, ""

        except asyncio.TimeoutError:
            return None, "download timed out (>120s)"
        except Exception as exc:
            return None, str(exc)


# ── Handlers ──────────────────────────────────────────────────────────────────
async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    text = (
        "🎬 *Downloader Bot*\n\n"
        "أرسل أي رابط من:\n"
        "• TikTok\n"
        "• Instagram (Reels / Posts)\n"
        "• Facebook\n"
        "• YouTube\n"
        "• X (Twitter)\n"
        "• Reddit\n\n"
        "سيسألك البوت عن الجودة ثم يرسل الملف مباشرة."
    )
    await update.message.reply_text(text, parse_mode=ParseMode.MARKDOWN)


async def cmd_help(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await cmd_start(update, context)


async def handle_url(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    text = update.message.text or ""
    url = extract_url(text)

    if not url:
        await update.message.reply_text("⚠️ ما وجدت رابطاً في رسالتك.")
        return

    platform = detect_platform(url)
    if platform == "Unknown":
        await update.message.reply_text(
            "⚠️ الرابط من منصة غير مدعومة.\n"
            "المنصات: TikTok · Instagram · Facebook · YouTube · X · Reddit"
        )
        return

    context.user_data["pending_url"] = url

    keyboard = [
        [
            InlineKeyboardButton("🎬 فيديو (أفضل جودة)", callback_data="dl:video"),
            InlineKeyboardButton("🎵 صوت فقط (MP3)", callback_data="dl:audio"),
        ]
    ]
    await update.message.reply_text(
        f"🔗 *{platform}* — اختر الصيغة:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN,
    )


async def handle_quality_choice(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()

    url = context.user_data.get("pending_url")
    if not url:
        await query.edit_message_text("⚠️ انتهت الجلسة، أعد إرسال الرابط.")
        return

    _, quality = query.data.split(":", 1)  # "video" | "audio"
    label = "الفيديو" if quality == "video" else "الصوت"

    await query.edit_message_text(f"⏳ جاري تحميل {label}…")
    await context.bot.send_chat_action(query.message.chat_id, ChatAction.UPLOAD_VIDEO)

    file_path, error = await download_media(url, quality)

    if error or not file_path:
        await query.edit_message_text(
            f"❌ فشل التحميل:\n`{error}`",
            parse_mode=ParseMode.MARKDOWN,
        )
        return

    size_mb = file_path.stat().st_size / (1024 * 1024)
    if size_mb > MAX_FILE_MB:
        file_path.unlink(missing_ok=True)
        await query.edit_message_text(
            f"❌ الملف ({size_mb:.1f} MB) يتجاوز حد تيليجرام ({MAX_FILE_MB} MB)."
        )
        return

    try:
        await query.edit_message_text("📤 جاري الرفع…")
        with open(file_path, "rb") as f:
            if quality == "audio":
                await context.bot.send_audio(
                    chat_id=query.message.chat_id,
                    audio=f,
                    filename=file_path.name,
                )
            else:
                await context.bot.send_video(
                    chat_id=query.message.chat_id,
                    video=f,
                    filename=file_path.name,
                    supports_streaming=True,
                )
        await query.delete_message()
    except Exception as exc:
        await query.edit_message_text(f"❌ فشل الإرسال: `{exc}`", parse_mode=ParseMode.MARKDOWN)
    finally:
        file_path.unlink(missing_ok=True)
        context.user_data.pop("pending_url", None)


# ── Main ──────────────────────────────────────────────────────────────────────
def main() -> None:
    app = Application.builder().token(BOT_TOKEN).build()

    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("help", cmd_help))
    app.add_handler(CallbackQueryHandler(handle_quality_choice, pattern=r"^dl:"))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_url))

    logger.info("Starting webhook on port %d …", PORT)
    app.run_webhook(
        listen="0.0.0.0",
        port=PORT,
        webhook_url=f"{WEBHOOK_URL}/webhook",
        url_path="/webhook",
    )


if __name__ == "__main__":
    main()
